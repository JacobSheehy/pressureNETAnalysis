tinyMCE.addI18n("en.grappelli",{
grappelli_adv_desc:"Show/Hide Advanced Menu",
grappelli_documentstructure_desc:"Show/Hide Document Structure",
});