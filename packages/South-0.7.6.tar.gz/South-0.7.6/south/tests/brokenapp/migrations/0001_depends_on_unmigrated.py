from south.db import db
from django.db import models

class Migration:

    depends_on = [('unknown', '0001_initial')]
    
    def forwards(self):
        pass
    
    def backwards(self):
        pass

